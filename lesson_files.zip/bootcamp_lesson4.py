# cnt = 0

# with open('logs.txt') as fl:
#     for line in fl:
#         if 'successful' in line:
#             cnt+=1

# print(cnt)



# Practice2: You file named sales_data.csv that contains sales records.
# Calculate the total sale amount and save this result to the new file named output.csv

# sum_sales = 0
# with open('sales_data.csv') as fl:
#     for line in fl:
#         sum_sales += int(float(line.strip().split(',')[-1]))

# print(sum_sales)



# with open('output.csv', 'w') as fl:
#     fl.write(str(sum_sales))

# employee_info = {
#     "name": "John Doe",
#     "age": 30,
#     "department": "Engineering",
#     "email": "johndoe@example.com",
#     "is_manager": False
# }



# for i in employee_info:
#     print(i)


# for key in employee_info.keys():
#     print(key)

# print(employee_info.values())


# for key,value in employee_info.items():
#     print(key,value)

# employees = {
#     101: {"name": "Alice", "department": "Engineering", "salary": 75000},
#     102: {"name": "Bob", "department": "Marketing", "salary": 65000},
#     103: {"name": "Charlie", "department": "Sales", "salary": 50000},
#     104: {"name": "Diana", "department": "Engineering", "salary": 80000},
#     105: {"name": "Ethan", "department": "Marketing", "salary": 72000}
# }

# dep_sals = {}


# for value in employees.values():
#     dep = value['department']
#     salary = value['salary']

#     if dep not in dep_sals:
#         dep_sals[dep] = [salary]
#     else:
#         dep_sals[dep].append(salary)

# for key, value in dep_sals.items():
#     print(key, sum(value)/len(value))


hawks = """Griffith stood at the peak, his eyes gazing over the battlefield. 'This is the moment,' he thought, 
           'when fate hangs in balance.' Beside him, Guts, with his enormous sword, was ready to dive into the fray.
           'For the Band of the Hawk,' Guts whispered, determination etched on his face.
"""


char_counter = {}

# Practice4: Calculate the frequency of each character in a given string hawks and assign result
#  to the dictionary char_counter.
# Calculate the total number of character occurrences in the given text with help of char_counter.
# Find character with minimum and maximum occurrence(s)


# for char in hawks:
#     if char not in char_counter:
#         char_counter[char] = 1
#     else:
#         char_counter[char] += 1

# for char in hawks:
#     char_counter[char] = char_counter.get(char, 0) + 1

# print(char_counter)

# max_occurences = max(char_counter.values())
# min_occurences = min(char_counter.values())
# max_chars = {}
# min_chars = {}
# for key, value in char_counter.items():
#     if value == max_occurences:
#         max_chars[key] = value
#     elif value == min_occurences:
#         min_chars[key] = value
# print('Max occurences: ', max_chars)
# print('Min occurences: ', min_chars)



# from collections import Counter

# print(Counter(hawks))

# Practice5: Refer and read recent file sales_data.csv.
# Calculate total of sale amounts for each product.

sales = {}

with open('sales_data.csv') as fl:
    for line in fl:
        data = line.strip().split(',')
        goods, amount = data[1], int(float(data[-1]))
        
        if goods not in sales:
            sales[goods] = amount
        else:
            sales[goods] += amount

print(sales)
