# # HW4: Determine the winner of the Vowel-Consonant Game.
# #  The game is played with a given string S, and two players, Mirza and Turan
# # String: Both players are given the same string, S.
# # Substrings: Players create substrings using the letters of S. +
# # Conditions:
# # Mirza's substrings must start and end with consonants. 
# # Turan's substrings must start and end with vowels. 
# # End Condition: The game ends when all possible substrings conforming to the rules have been created.
# # Scoring: Players score points based on the length of each unique substring they create.
# # Output: The name of the winner and their score, or "Draw" if the game ends in a tie.
# # Example:  Apple -> Mirza: p,pp,ppl,pl,l; Turan: a,apple,e

# vowels = 'aioue'

# s = 'apple'

# turan_substrings = []
# turan_point = 0

# mirza_substrings = []
# mirza_point = 0

# for i in range(len(s)):
#     for j in range(i+1, len(s)+1):
#         substring = s[i:j]

#         if substring[0] in vowels and substring[-1] in vowels and substring not in turan_substrings:
#             turan_point += len(substring)
#             turan_substrings.append(substring)
#         elif substring[0] not in vowels and substring[-1] not in vowels and substring not in mirza_substrings:
#             mirza_point += len(substring)
#             mirza_substrings.append(substring)

# print(mirza_point)
# print(turan_point)



# db1 = set([101, 102, 103, 104])
# db2 = set([103, 104, 105, 106])

# db1.difference_update(db2)

# print(db1)


# a, *b, c = (4,5,6,7,8)

# print(a, b, c)

# transactions = [
#     (1001, 'C001', 250.00),
#     (1002, 'C002', 300.00),
#     (1003, 'C001', 150.00),
#     (1004, 'C003', 500.00),
#     (1005, 'C002', 200.00),
#     (1006, 'C001', 100.00)
# ]


# total_amount = {}

# for transaction in transactions:
#     id, amount = transaction[1], transaction[2]

#     total_amount[id] = total_amount.get(id, 0) + amount

# print(total_amount)


# lst = []
# for i in transactions:
#     lst.append(i[1])

# print(set(lst))

# a = ['book','pen', 'cup']

# for ind, elem in enumerate(a):
#     print(ind, elem)

# sales_data = [
#     (200, 220, 250, 210, 300, 320, 500, 480, 450, 400, 380, 360),  # Salesperson 1
#     (150, 180, 210, 200, 230, 250, 300, 310, 300, 290, 280, 270),  # Salesperson 2
#     (100, 120, 150, 130, 140, 160, 180, 170, 160, 150, 140, 130)   # Salesperson 3
# ]

# monthly_sales= {}

# for data in sales_data:
#     for ind, sale in enumerate(data, start=1):
#         if ind not in monthly_sales:
#             monthly_sales[ind] = sale
#         else:
#             monthly_sales[ind] += sale

# print(monthly_sales)


a = 5

# for i in range(a, -1, -1):
#     print(i)


# while a >= 0:
#     print(a)
#     a-=1

#     if a == 2:
#         continue


# break
# # pass
# # continue


# import random as rnd

# number = rnd.randint(1, 10)


# while True:
#     user_number = int(input('Enter a number: '))

#     if user_number == number:
#         print('You find it!')
#         break
#     else:
#         continue

# number = 1
# while number <= 20:
#     if number % 2 == 0:
#         number += 1
#         continue
#     print(number)
#     number += 1



# Practice7: Keep asking for user input until they provide a non-empty string.

# is_empty = True


# while is_empty:
#     user_input = input('Please enter nonempty input: ')

#     if user_input != '':
#         is_empty = False

limit = 100

a, b = 0,1


while a <= limit:
    print(a, end=' ')
    a, b = b, a+b

